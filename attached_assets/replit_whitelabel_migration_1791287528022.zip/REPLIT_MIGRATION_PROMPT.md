# Project 2 → Project 1: White-Label / Private-Label Feature Migration

## Objective

I have two projects:

- Project 1: Our existing crypto exchange codebase. This is the main destination codebase.
- Project 2: Our existing white-label/private-label platform, including the admin panel and functionality that allows a user/customer to configure and build their own white-label exchange.

I want to migrate the complete white-label/private-label functionality from Project 2 into Project 1.

Final result:

Project 1 = existing crypto exchange + complete white-label/private-label system from Project 2.

A user should be able to use Project 1 and, when they choose to create/build their own white-label exchange, have the same capabilities that currently exist in Project 2.

---

# IMPORTANT RULES

## 1. Do NOT start by copying files

First perform a complete technical audit of both projects.

Understand:

- frontend architecture
- backend architecture
- database/schema
- authentication
- authorization/roles
- APIs
- admin panels
- configuration systems
- environment variables
- storage
- queues/jobs
- webhooks
- payment integrations
- blockchain integrations
- exchange/trading functionality
- user management
- white-label configuration
- branding
- domains/subdomains
- deployment configuration
- feature flags
- billing/subscription functionality
- notifications
- email/SMS
- security mechanisms
- third-party integrations

Create a migration map before modifying Project 1.

---

# PHASE 1 — AUDIT PROJECT 2

Identify EVERY feature related to the white-label/private-label system.

Do not limit the audit to visible UI.

Trace each feature through:

UI → frontend logic → API → backend services → database → background jobs → integrations → configuration → deployment.

For every feature, document:

- feature name
- location/file/module
- frontend components
- backend endpoints/services
- database tables/collections
- environment variables
- external services
- dependencies
- permissions/roles
- tenant/customer relationships
- configuration
- validation
- security requirements

Create a feature inventory.

Example:

| Feature | Frontend | Backend | Database | Dependencies | Tenant-specific |
|---|---|---|---|---|---|
| Branding | ... | ... | ... | ... | Yes |
| Custom domain | ... | ... | ... | ... | Yes |
| Exchange settings | ... | ... | ... | ... | Yes |
| Trading pairs | ... | ... | ... | ... | Yes |
| Fees | ... | ... | ... | ... | Yes |
| User management | ... | ... | ... | ... | Yes |
| KYC settings | ... | ... | ... | ... | Yes |
| Wallet settings | ... | ... | ... | ... | Yes |

Do not assume a feature is unnecessary simply because it is not visible in the UI.

---

# PHASE 2 — AUDIT PROJECT 1

Analyze Project 1 independently.

Identify:

- current architecture
- existing exchange functionality
- database architecture
- authentication
- user model
- admin model
- roles/permissions
- API structure
- frontend routing
- backend routing
- wallet system
- trading engine
- orders
- balances
- deposits
- withdrawals
- KYC
- fees
- notifications
- integrations
- configuration
- deployment

Determine where Project 2 functionality should integrate with Project 1.

---

# PHASE 3 — CREATE A COMPATIBILITY / MIGRATION PLAN

Before implementing anything, compare the two projects.

Identify:

1. Duplicate functionality
2. Conflicting functionality
3. Different database structures
4. Different authentication systems
5. Different user models
6. Different admin systems
7. Different APIs
8. Different naming conventions
9. Different dependencies
10. Features that need adaptation rather than direct copying

For every Project 2 feature, determine:

- COPY
- ADAPT
- REBUILD
- MERGE
- REPLACE

Do not overwrite Project 1's existing exchange functionality unless explicitly necessary.

---

# PHASE 4 — WHITE-LABEL ARCHITECTURE

The migrated system must be designed as a proper multi-tenant/white-label architecture.

The goal is NOT simply to duplicate Project 1 for every customer.

Instead, create a tenant/white-label layer.

Conceptually:

Platform
│
├── Tenant / White Label A
│   ├── Branding
│   ├── Domain
│   ├── Users
│   ├── Exchange configuration
│   ├── Trading configuration
│   ├── Fees
│   ├── Assets
│   ├── Trading pairs
│   ├── KYC configuration
│   ├── Wallet configuration
│   └── Other tenant settings
│
├── Tenant / White Label B
│   └── ...
│
└── Platform Admin

Each tenant must be isolated correctly.

A tenant must NEVER be able to access another tenant's:

- users
- balances
- wallets
- orders
- trades
- transactions
- API keys
- KYC data
- settings
- private configuration
- secrets

Implement tenant isolation at the backend/data-access level, not only in the frontend.

---

# PHASE 5 — MOVE THE PROJECT 2 ADMIN / WHITE-LABEL PANEL

Migrate the functionality of Project 2's white-label/private-label panel into Project 1.

The user should be able to:

1. Create a white-label project
2. Configure the project
3. Configure branding
4. Upload logos/assets
5. Configure colors/theme
6. Configure exchange settings
7. Configure fees
8. Configure trading pairs
9. Configure supported assets
10. Configure deposits/withdrawals
11. Configure KYC/AML settings where applicable
12. Configure user settings
13. Configure notifications
14. Configure integrations
15. Configure domains/subdomains
16. Configure other settings currently available in Project 2

The exact feature set must come from the Project 2 audit.

Do not omit hidden/backend functionality.

---

# PHASE 6 — PRESERVE PROJECT 1 EXCHANGE ENGINE

Project 1's existing exchange functionality is critical.

Do not accidentally break:

- order creation
- order matching
- order cancellation
- balances
- wallet operations
- deposits
- withdrawals
- trading
- market data
- user authentication
- existing APIs
- existing integrations

If Project 2 contains a competing implementation, do NOT automatically replace Project 1's implementation.

Determine which implementation should be retained and create an integration layer where necessary.

---

# PHASE 7 — DATABASE MIGRATION

Create a proper database migration strategy.

Do NOT simply overwrite Project 1's database.

Identify all Project 2 tables/models required for white-label functionality.

For every model determine:

- whether Project 1 already has an equivalent
- whether it should be merged
- whether it should be renamed
- whether a tenant_id/white_label_id is required
- relationships
- indexes
- constraints
- unique constraints
- migrations
- existing-data compatibility

All tenant-specific data must have an explicit and reliable tenant relationship.

For example, where appropriate:

tenant_id
white_label_id
organization_id

Use the architecture that best fits the existing Project 1 codebase rather than blindly using these exact names.

---

# PHASE 8 — AUTHORIZATION

Implement proper role-based access control.

At minimum consider:

- Platform Super Admin
- White-Label Owner
- White-Label Admin
- White-Label Support
- White-Label User
- Standard Exchange User

Project 2's existing roles must also be analyzed and migrated.

Permissions must be enforced on the backend.

Never rely only on hiding frontend buttons/routes.

---

# PHASE 9 — CONFIGURATION SYSTEM

Create a clean configuration hierarchy.

For example:

Platform defaults
↓
White-label configuration
↓
User-specific settings where applicable

A white-label configuration should override platform defaults without modifying the core exchange code.

Avoid hardcoding tenant-specific values.

---

# PHASE 10 — BRANDING / CUSTOMIZATION

Migrate all Project 2 branding functionality.

This includes anything discovered during the audit such as:

- logo
- favicon
- colors
- typography
- theme
- landing page configuration
- exchange name
- email branding
- notification branding
- custom assets
- custom content
- custom domain
- SEO settings
- other configurable UI elements

The implementation should make branding dynamically selectable based on the current tenant.

---

# PHASE 11 — API AND BACKEND MIGRATION

Migrate all required Project 2 APIs/services.

Do not just copy routes.

For each endpoint:

- understand its purpose
- map its Project 2 dependencies
- adapt it to Project 1 architecture
- enforce authentication
- enforce tenant isolation
- enforce permissions
- validate input
- preserve error handling
- preserve audit logging where applicable

Use Project 1's conventions where possible.

---

# PHASE 12 — FRONTEND MIGRATION

Move the Project 2 white-label UI into Project 1 while adapting it to Project 1's frontend architecture.

Do not create duplicate systems if Project 1 already has equivalent components.

Reuse existing:

- UI components
- authentication
- routing
- API clients
- state management
- forms
- notifications
- layouts

where appropriate.

---

# PHASE 13 — ENVIRONMENT VARIABLES AND SECRETS

Audit all environment variables from Project 2.

Categorize them:

- required
- optional
- deprecated
- development-only
- production-only
- tenant-specific
- platform-wide

Never expose secrets in frontend code.

Never commit credentials/API keys/private keys to the repository.

If Project 2 requires external services, identify exactly what configuration Project 1 needs.

---

# PHASE 14 — EXTERNAL INTEGRATIONS

Identify all Project 2 integrations, including any:

- payment providers
- blockchain nodes
- wallet providers
- KYC providers
- AML providers
- email providers
- SMS providers
- storage providers
- analytics
- monitoring
- domain/DNS services
- third-party APIs

For every integration determine whether it should be:

1. platform-wide
2. tenant-specific
3. optional
4. configurable by the white-label owner

---

# PHASE 15 — SECURITY

Perform a security review after migration.

Pay particular attention to:

- tenant isolation
- IDOR vulnerabilities
- authorization bypasses
- API authorization
- admin privileges
- wallet security
- API keys
- private credentials
- secrets
- file uploads
- custom domains
- webhooks
- authentication
- session handling
- CSRF
- XSS
- SQL/NoSQL injection
- rate limiting
- audit logs

A tenant must never be able to manipulate another tenant by changing an ID in a request.

For example, this must be prevented:

GET /api/tenant/123/users

when the authenticated user belongs to tenant 456.

---

# PHASE 16 — TESTING

Create tests for the migrated functionality.

At minimum test:

### Tenant isolation

Tenant A cannot access Tenant B data.

### Authentication

Users can only access authorized areas.

### Admin permissions

Admins cannot perform actions outside their permissions.

### White-label creation

A platform admin can create a new white-label.

### Configuration

Changing Tenant A's configuration does not affect Tenant B.

### Branding

Each tenant displays its own branding.

### Exchange

Existing Project 1 exchange functionality continues working.

### Users

Users belong to the correct tenant.

### Trading

Orders/trades/balances remain isolated by tenant.

### Wallets

Wallets and transactions remain isolated.

### API

Tenant-aware API authorization works correctly.

---

# PHASE 17 — MIGRATION VALIDATION

After implementation, create a feature-by-feature comparison between Project 2 and the new implementation in Project 1.

Use:

| Project 2 Feature | Migrated? | Project 1 Location | Tested? | Notes |
|---|---|---|---|---|

Do not consider the migration complete until every relevant Project 2 white-label feature has been accounted for.

---

# IMPORTANT DEVELOPMENT PRINCIPLE

Do not make Project 1 dependent on Project 2 at runtime.

The final system should be a standalone Project 1 codebase containing the required white-label functionality.

Project 2 can remain untouched as a reference/source during migration.

---

# FINAL EXPECTED RESULT

The final Project 1 should provide:

### Existing exchange

Everything that currently works in Project 1.

PLUS:

### White-label platform

Everything required to create and operate a white-label exchange that currently exists in Project 2.

The architecture should allow:

Platform Admin
→ Create White Label
→ Configure White Label
→ Configure branding/domain/features
→ Deploy/activate White Label
→ White-label users access their exchange

while all tenants remain securely isolated.

---

# WORKFLOW REQUIREMENT

Do this in stages.

Do NOT make one huge uncontrolled rewrite.

First produce:

1. Project 2 feature inventory
2. Project 1 architecture inventory
3. Database comparison
4. API comparison
5. Dependency comparison
6. White-label feature map
7. Conflict list
8. Migration plan
9. Implementation order

Then begin implementation in small, verifiable phases.

After each major phase:

- run tests
- run build
- check database migrations
- check API functionality
- check frontend
- verify existing Project 1 functionality has not regressed

Keep the application runnable throughout the migration whenever reasonably possible.

Before changing any critical exchange functionality, create a backup/checkpoint/commit so changes can be reverted safely.

Do not delete Project 2 functionality until the corresponding functionality has been successfully migrated and verified in Project 1.
